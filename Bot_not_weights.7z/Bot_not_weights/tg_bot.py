import telebot
import logging
from my_token import token
from model import CarModel, predict, inverse_mappa, binary_predict, BinaryModel
import torch
from torchvision.models import efficientnet_v2_s
import cv2
import os
from copy import deepcopy


logger = telebot.logger
telebot.logger.setLevel(logging.DEBUG)

# telebot.logging.LogRecord(name = telebot , level = one , pathname = "../nikita/logging.txt" )
# записывать в список текст и потом дёргать в функцию text = []

bot = telebot.TeleBot(token)

# init car model

model = efficientnet_v2_s(weights='DEFAULT')
num_classes = 10

car_model = CarModel(no_input=model.classifier[1].in_features, no_output=num_classes)

model.classifier = car_model

model = torch.load('model_efficientnet_s_new.bin')
model = model
model.eval()
#map_location="cpu"
# binary model
binary_model = torch.load('new_binary_model.bin',map_location="cpu" )
binary_model = binary_model
binary_model = binary_model.eval()


@bot.message_handler(commands=["start"])
def get_text_messages(message):
        bot.send_message(
            message.from_user.id,
            "Привет, чем я могу тебе помочь? Можешь загрузить фото /photo",
        )
        
@bot.message_handler(content_types=['photo'])
def handle_photo(message):
    file_id = bot.get_file(message.photo[len(message.photo) - 1].file_id).file_id
    file_info = bot.get_file(file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    
    with open(f"pics/{file_id}.jpg", 'wb') as new_file:
        new_file.write(downloaded_file)
        
    img_name = os.path.join('pics', file_id+'.jpg')
        
    image = cv2.imread(img_name)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    binary = binary_predict(deepcopy(image), binary_model)
    
    if binary[0]:
        car_type = False
    else:
        car_type = True
    
    pred_type = predict(deepcopy(image), model, inverse_mappa)
    logger.info(f"PREDICTED TYPE IS {pred_type}, {binary}")
    
    if car_type:
        msg = f'I do not think this is a car.'
    else:
        msg = f'This is a car. Its body type is {pred_type}.'
    
    bot.send_message(
            message.from_user.id,
            msg,
        )

@bot.message_handler(commands=["photo"])
def handle_docs_photo(message):
    if message.text == "Загрузи фото".lower() or "Загрузи фото".upper():
        file_info = bot.get_file(message.photo[len(message.photo) - 1].file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        src = "../nikita/" + file_info.file_path
        with open(src, "wb") as new_file:
            new_file.write(downloaded_file)

        bot.reply_to(message, "Пожалуй, я сохраню это")


bot.infinity_polling()
